package com.arabdubai.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val pickVideo = 100
    private var selectedVideo: Uri? = null
    private lateinit var status: TextView
    private lateinit var videoName: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 12, 30)
        window.navigationBarColor = Color.rgb(18, 12, 30)

        val bg = Color.rgb(15, 12, 24)
        val purple = Color.rgb(132, 76, 220)
        val white = Color.WHITE

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "Arab Dub AI"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "دبلجة الأنمي والأفلام إلى العربية الفصحى"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        page.addView(subtitle)

        val choose = Button(this).apply {
            text = "اختيار فيديو من الهاتف"
            setOnClickListener { openVideoPicker() }
        }
        page.addView(choose, matchWidth())

        videoName = TextView(this).apply {
            text = "لم يتم اختيار فيديو بعد"
            textSize = 14f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 20)
        }
        page.addView(videoName)

        val voiceTitle = TextView(this).apply {
            text = "أصوات الشخصيات"
            textSize = 18f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        page.addView(voiceTitle)

        val voices = Spinner(this)
        val voiceOptions = listOf("أصوات متعددة تلقائيًا", "أصوات رجالية ونسائية")
        voices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, voiceOptions)
        page.addView(voices, matchWidth())

        val dub = Button(this).apply {
            text = "ابدأ الدبلجة"
            setBackgroundColor(purple)
            setTextColor(white)
            setOnClickListener {
                if (selectedVideo == null) {
                    status.text = "اختر فيديو أولًا."
                } else {
                    status.text = "واجهة الاختيار جاهزة. محرك الدبلجة يحتاج إلى ربط خادم ذكاء اصطناعي قبل إنتاج الصوت العربي."
                }
            }
        }
        val dubParams = matchWidth()
        dubParams.topMargin = 24
        page.addView(dub, dubParams)

        status = TextView(this).apply {
            text = "الدبلجة تتطلب اتصالًا بالإنترنت."
            textSize = 14f
            setTextColor(Color.rgb(220, 205, 245))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        page.addView(status)

        val offline = TextView(this).apply {
            text = "بعد اكتمال الدبلجة وحفظ الملف على الهاتف، يمكن مشاهدته دون إنترنت."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        page.addView(offline)

        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedVideo = uri
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                videoName.text = "تم اختيار الفيديو بنجاح"
                status.text = "الفيديو جاهز للمرحلة التالية."
            }
        }
    }
}
